const STORAGE_KEY = "cml2026";

const participantes = [
"Assembly","Fortran","COBOL","Lisp","C","Swift","C++","Java",
"Python","JavaScript","PHP","C#","Ruby","Go","TypeScript","Rust"
];

// ================= STORAGE =================

function loadData() {
  const data = localStorage.getItem(STORAGE_KEY);
  if (data) return JSON.parse(data);

  const initial = {
    participantes,
    partidas: [],
    resultados: {},
    ranking: [],
    playoffs: {
      quartas: [],
      semi: [],
      final: []
    },
    status: {
      fase: "grupos"
    }
  };

  saveData(initial);
  return initial;
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

let state = loadData();

// ================= UTIL =================

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function matchKey(a, b) {
  return [a, b].sort().join("-");
}

// ================= SORTEIO =================

function gerarRodadas() {
  const confrontos = new Set();
  const rodadas = [];

  for (let r = 0; r < 5; r++) {
    let tentativa = 0;

    while (true) {
      tentativa++;
      if (tentativa > 1000) throw "Erro no sorteio";

      const embaralhado = shuffle(participantes);
      const rodada = [];
      let valido = true;

      for (let i = 0; i < embaralhado.length; i += 2) {
        const a = embaralhado[i];
        const b = embaralhado[i + 1];
        const key = matchKey(a, b);

        if (confrontos.has(key)) {
          valido = false;
          break;
        }

        rodada.push({ a, b });
      }

      if (valido) {
        rodada.forEach(j => confrontos.add(matchKey(j.a, j.b)));
        rodadas.push(rodada);
        break;
      }
    }
  }

  state.partidas = rodadas;
  saveData(state);
  render();
}

// ================= RESULTADOS =================

function parseResultado(val) {
  const map = {
    "3x0": [3,0],
    "2x1": [2,1],
    "1x2": [1,2],
    "0x3": [0,3]
  };
  return map[val] || null;
}

// ================= RANKING =================

function calcularRanking() {
  const tabela = {};

  participantes.forEach(p => {
    tabela[p] = {
      nome: p,
      pontos: 0,
      saldo: 0,
      votos: 0,
      vitorias: 0,
      v3: 0,
      adversarios: []
    };
  });

  state.partidas.forEach(rodada => {
    rodada.forEach(jogo => {
      const key = matchKey(jogo.a, jogo.b);
      const res = state.resultados[key];
      if (!res) return;

      const [aScore, bScore] = parseResultado(res);

      const A = tabela[jogo.a];
      const B = tabela[jogo.b];

      A.votos += aScore;
      B.votos += bScore;

      A.saldo += aScore - bScore;
      B.saldo += bScore - aScore;

      A.adversarios.push(jogo.b);
      B.adversarios.push(jogo.a);

      if (aScore > bScore) {
        A.vitorias++;
        if (aScore === 3) A.v3++;
      } else {
        B.vitorias++;
        if (bScore === 3) B.v3++;
      }

      A.pontos += aScore;
      B.pontos += bScore;
    });
  });

  const lista = Object.values(tabela);

  lista.forEach(t => {
    t.buchholz = t.adversarios.reduce((sum, adv) => {
      return sum + (tabela[adv]?.pontos || 0);
    }, 0);
  });

  lista.sort((a, b) =>
    b.pontos - a.pontos ||
    b.saldo - a.saldo ||
    b.votos - a.votos ||
    b.vitorias - a.vitorias ||
    b.v3 - a.v3 ||
    b.buchholz - a.buchholz
  );

  state.ranking = lista;
  saveData(state);
}

// ================= RENDER =================

function render() {
  calcularRanking();
  renderGrupos();
  renderRanking();
}

function renderGrupos() {
  const container = document.getElementById("grupos");
  container.innerHTML = "";

  state.partidas.forEach((rodada, i) => {
    const div = document.createElement("div");
    div.innerHTML = `<h3>Rodada ${i+1}</h3>`;

    rodada.forEach(j => {
      const key = matchKey(j.a, j.b);

      const input = document.createElement("input");
      input.value = state.resultados[key] || "";
      input.placeholder = "2x1";

      input.onchange = () => {
        const val = input.value;
        if (!parseResultado(val)) {
          input.value = "";
          return;
        }

        state.resultados[key] = val;
        saveData(state);
        render();
      };

      const p = document.createElement("p");
      p.append(`${j.a} `, input, ` ${j.b}`);
      div.appendChild(p);
    });

    container.appendChild(div);
  });
}

function renderRanking() {
  const container = document.getElementById("ranking");
  container.innerHTML = "";

  state.ranking.forEach((t, i) => {
    const div = document.createElement("div");

    if (i < 8) div.style.background = "#1e3a8a";

    div.innerHTML = `
      ${i+1}º ${t.nome} | ${t.pontos} pts | saldo ${t.saldo}
    `;

    container.appendChild(div);
  });
}

// ================= INIT =================

document.getElementById("gerar").onclick = gerarRodadas;

render();