from django.shortcuts import render, get_object_or_404
from django.views import View

from .models import LikePost
from apps.posts.models import Post


# Create your views here.
class LikedPost(View):
    def post(self, request):
        pk = request.POST.get('post-link')
        user = request.user

        post = get_object_or_404(Post, pk=pk)

        like, created = LikePost.objects.get_or_create(post=post, user=user)
        likes = post.likes.count()

        context = {
            'likes': likes,
        }
        if created:
            return render(request, 'engagements/partials/liked.html', context)

        like.delete()
        return render(request, 'engagements/partials/no-liked.html', context)
