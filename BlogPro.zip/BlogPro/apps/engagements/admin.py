from django.contrib import admin

from .models import LikePost
# Register your models here.

admin.site.register(LikePost)
