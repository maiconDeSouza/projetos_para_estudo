import { render, actions } from './utils.js'

const buttonChooseQuestion = document.querySelector('.area-questions__list')
const ulAnswers = document.querySelector('.main__answers-list')
const ulFooterActions = document.querySelector('.main__footer-list')

document.addEventListener('DOMContentLoaded', e => {
    render.renderQuestions()
    render.renderRanking()
})

buttonChooseQuestion.addEventListener('click', e => {
    if(e.target.parentElement.dataset.id){
        render.renderQuestion(e.target.parentElement.dataset.id)
    }
})

ulAnswers.addEventListener('click', e => {
    if(e.target.parentElement.tagName === 'LI'){
        const response = e.target.closest('p').textContent
        actions.answer(response)
    }
})

ulFooterActions.addEventListener('click', e => {
    if(e.target.closest('.main__footer-button-confirme')){
        const id = document.querySelector('.main__answers-item.active').dataset.id
        const answer = document.querySelector('.main__answers-item.active > p').textContent
        actions.buttonConfirme(id, answer)
        render.renderQuestion(id)
    }
})