import { questions } from './questions.js'

export const issuesManagement = {
    questions,
    points: 0,
    answered: [],
    idQuestionsRandom: new Set(),
    questionsID(){
        while(this.questions.length !== this.idQuestionsRandom.size){
            const index = Math.floor(Math.random() * this.questions.length)
            this.idQuestionsRandom.add(this.questions[index].id)
        }

        return this.idQuestionsRandom
    }
}

export const localStoreOperation = {
    getLocalStore(){
        const data = JSON.parse(localStorage.getItem('ranking-quiz')) ?? []
        return data
    }
}

export const render = {
    renderQuestions(){
        const frag = document.createDocumentFragment()
        const ul = document.querySelector('.area-questions__list')
        const liTemplate = ul.querySelector('.area-questions__template')
        const idQuestionsRandom = Array.from(issuesManagement.questionsID())

        idQuestionsRandom.forEach((id, index) => {
            const li = liTemplate.content.querySelector('.area-questions__item').cloneNode(true)
            li.dataset.id = id
            li.querySelector('button').textContent = `Pergunta ${index + 1}`
            frag.appendChild(li)
        })
        ul.appendChild(frag)
    },
    renderRanking(){
        const frag = document.createDocumentFragment()
        const ul = document.querySelector('.ranking__list')
        const liTemplate = ul.querySelector('.ranking__template')

        const data = localStoreOperation.getLocalStore()

        data.sort((a, b) => b.points - a.points)

        data.forEach(item => {
            const li = liTemplate.content.querySelector('.ranking__item').cloneNode(true)
            li.querySelector('.ranking__name').textContent = item.name
            li.querySelector('.ranking__points').textContent = `${item.points} Pontos`
            frag.appendChild(li)
        })

        ul.appendChild(frag)
    },
    renderQuestion(id){
        const question = issuesManagement.questions.find(question => question.id === id)
        const frag = document.createDocumentFragment()
        const header = document.querySelector('.header')
        const ul = document.querySelector('.main__answers-list ')
        const liTemplates = document.querySelector('.main__answers-template')
        const buttonsQuestions = document.querySelectorAll('.area-questions__item button')
        const options = {
            0: 'a',
            1: 'b',
            2: 'c',
            3: 'd'
        }
        

        header.querySelector('h2').textContent = `${question.question}`
        const shuffledOptions = question.options
        .map(value => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({ value }) => value)

        shuffledOptions.forEach((option, index) => {
            const li = liTemplates.content.querySelector('.main__answers-item').cloneNode(true)
            li.querySelector('b').textContent = options[index]
            li.querySelector('p').textContent = option
            li.dataset.id = id
            frag.appendChild(li)
        })
        ul.appendChild(frag)

        buttonsQuestions.forEach(button => {
            button.parentElement.dataset.id === id ? button.classList.toggle('active') : button.classList.toggle('deactivate')
            if(issuesManagement.answered.some(valueId => valueId === id)){
                button.classList.add('answered')
            }
        })
    }
}

export const actions = {
    jump: 0,
    answer(response){
        const liAnswers = document.querySelectorAll('.main__answers-item')
        

        liAnswers.forEach(li => {
            li.querySelector('p').textContent === response ? li.classList.toggle('active') : li.classList.toggle('disabled')
        })

        this.buttonsAction()
    },
    buttonsAction(){
        const buttonsAction = document.querySelectorAll('.main__footer-item button')

        buttonsAction.forEach(button => {
            if(!button.classList.contains('main__footer-button-jump')){
                button.disabled = !button.disabled
            }


            if(button.classList.contains('main__footer-button-jump')){
                button.disabled = !button.disabled
                if(this.jump >= 3){
                    button.disabled = true
                }
            }
        })
    },
    buttonConfirme(id, response){
        const question = issuesManagement.questions.find(question => question.id === id)
        if(question.answer === response){
            issuesManagement.points++
            issuesManagement.answered.push(id)
        }
    }
}

// export function initQuestions(){
//     const ul = document.querySelector('.area-card-questions__list')
//     const templateAreaCardQuestion = document.querySelector('.area-card-questions__list template')
//     const frag = document.createDocumentFragment()
//     const idQuestionsRandom = new Set()

//     while(questions.length !== idQuestionsRandom.size){
//         const index = Math.floor(Math.random() * questions.length)

//         idQuestionsRandom.add(questions[index].id)
//     }

//     Array.from(idQuestionsRandom).forEach((item, index) => {
//         const li = templateAreaCardQuestion.content.querySelector('.area-card-questions__item')
//         const span = li.querySelector('article span')
//         li.dataset.id = item
//         span.textContent = `Pergunta ${index + 1}`
//         frag.appendChild(li)
//     })

//     ul.appendChild(frag)
// }

