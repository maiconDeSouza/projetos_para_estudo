from django.urls import path

from . import views

app_name = 'crud'
urlpatterns = [
    path('add/', views.CRUD.as_view(), name='add'),
    path('del/<uuid:pk>', views.CRUD.as_view(), name='del'),
]
